#include <stdio.h>

/*6. Faça o mesmo exercício, atribuindo valor às variávies A e B (não é necessário
solicitar ao usuário, os valores serão atribuídos no próprio código)*/

int main()
{
int a, b, x;
a = 2;
b = 4;
printf("%i + %i ==  %i", a, b, a + b);

}
