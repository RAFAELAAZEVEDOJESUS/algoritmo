#include<stdio.h>

/*5. Faça o mesmo exercício, porém, realizando o calculo dentro do print*/

int main(){
	
	int main(){
		
		int A,B,X;
		
		printf("Digite o valor de A:");
		scanf("%d",&A);
		
		printf("Digite o valor de B:");
		scanf("%d",&B);
		
		X=A+B;
		
		printf("O valor de A + B e %d:",X);
		
	}
	
	return 0;
}