#include<stdio.h>

/*/*1. O seu primeiro programa em qualquer linguagem de programação normalmente é
o "Hello World!". Neste primeiro problema tudo o que você precisa fazer é imprimir
esta mensagem na tela.*/

int main(){

    printf("Hello World!");
}
