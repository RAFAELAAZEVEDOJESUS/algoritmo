#include<stdio.h>
int main (){

int dias
printf("Os dias da semana se refere a que numero?");
scanf("%i,&dias");





}