#include<stdio.h>

/*2. Faça um algoritmo que imprima o poema abaixo, com a mesma formatação:
Caderno de poesias é um belo lugar.
Tantas coisas lindas que eu gostaria de falar.
Eu falo em forma de versos para todos poderem escutar.
Agora você já sabe por que os poetas passam os dias escrevendo em seus
cadernos de poesias.
*/

int main(){
	
	
	
	printf("\nCaderno de poesias e um belo lugar.");
	printf("\nTantas coisas lindas que eu gostaria de falar");
	printf("\nEu falo em forma de versos para todos poderem escutar");
	printf("\nAgora voce ja sabe por que os poetas passam os dias escrevendo em seus \ncadernos de poemas.");

	return 0;
		
}