#include <stdio.h>
#include <locale.h>
#include <math.h>

int main (){
setlocale(LC_ALL, "Portuguese");

/*
printf("Curso: Algoritmo e programacao./n");
printf("Professor: Joyce Siqueira./n");
printf("Aluno: Maria Rafaela A. A. de Jesus./n");
printf("link Git: https://github.com/RAFAELAAZEVEDOJESUS/algoritmo");
printf("VS CODE")

A




char alternativas ='\0';



printf(" Digite a alternativa:(A, B, C):");
scanf("%c", &alternativas);

switch(alternativas){

    case 'A':
        printf("A");
        break;

    case 'B':
        printf("B");
        break;

    case 'C':
        printf("C");
        break;

    default:
        printf("Opção inválida.");
        break;
*/

    
    
   /*double a,b,c =0;

    printf("Digite o valor do cateto oposto:");
    scanf("%lf",&b);

    printf("Digite o valor do cateto adjacente:");
    scanf("%lf",&c);

    a=pow(b,2)+pow(c,2);
    printf("Valor do A: %lf\n",a);

    a=sqrt(a);
    printf("Valor do A: %lf\n",a);
    
    printf("Seno é igual a: %lf", b/a);
    
    */
    
    /*
    int ano =0;
     char nome[30];

    printf("Qual seu nome?");
    scanf("%29s",nome);
    fflush(stdin);
    printf("Qual o ano que nasceu?");
    scanf("%i",&ano);


    while (!(ano >= 1900 && ano <= 2022) ){
        printf("Digite o ano do nascimento:");
        scanf("%i", &ano);
    }
    

    printf("Valor do ano %d\n", ano);

    if((ano % 4 == 0) && (ano % 100 != 0) || (ano % 4 == 0) && (ano % 100 == 0) && (ano % 400 == 0))
    {
        printf("O ano e bissexto.");
    }else{
        printf("O ano nao e bissexto. \n");
    }
}
    */

    




    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;

}
